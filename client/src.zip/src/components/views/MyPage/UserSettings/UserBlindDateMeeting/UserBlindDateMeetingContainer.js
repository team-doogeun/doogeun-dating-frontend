import React from 'react';
import UserBlindDateMeetingView from './UserBlindDateMeetingView';

const UserBlindDateMeetingContainer = () => {
  return <UserBlindDateMeetingView />;
};
export default UserBlindDateMeetingContainer;
